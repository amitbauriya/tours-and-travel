	 <div class="header-top">
		 <!--container-->
		  <div class="container">
			 <div class="top-nav">
						<div class="logo">
							<a href="index.php"  onclick="javascript:window.open('index.php','_self')"><img src="images/logo.png" id="section-1" class="img-responsive" alt=""/></a>
						</div>
						<div class="menu">
						<ul id="nav">
							 <li><a href="index.php#section-1"  onclick="javascript:window.open('index.php','_self')">                            Home</a></li>
							 <li><a href="index.php#section-2"  onclick="javascript:window.open('index.php#section-2','_self')">                           About</a></li>
							 <li><a href="index.php#section-3"  onclick="javascript:window.open('index.php#section-3','_self')">                             Gallery</a></li>
                        <li><a href="category.php" onclick="javascript:window.open('category.php','_self')">Category</a></li>
							 <li><a href="index.php#section-4"   onclick="javascript:window.open('index.php#section-4','_self')">                            Map your Plan</a></li>
							 <li><a href="index.php#section-5"   onclick="javascript:window.open('index.php#section-5','_self')">                              Contact</a></li>
							 <div class="clearfix"></div>
						 </ul>
						 </div>
			 </div>
			  <div class="clearfix"> </div>
			

		 </div>
		 <!--/container-->
	 </div>